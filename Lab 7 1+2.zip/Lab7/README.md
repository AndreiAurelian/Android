# Android- Andrei Ene 1241F

-A fragment is a type of sub-activity that can be used again in multipe activities
-Each fragment has its own lifecycle
-It's lifecycle is influenced directly by the activity's lifecycle
-The main advantage of using fragments is due to the convenience of reusing the components in different layouts
-I learned thet if an activity stops or is destroyed than its fragments do the same
-I learned how to use them (Method+Description)
		-to add a fragment to an activity using XML
-I used TTS for Text to Speech and that i need a specific language for it to work due to words being pronounced differently
-to turn the text into speech i used 	ACTION_RECOGNIZE_SPEECH	and the results are shown in onActivityResult(int, int, Intent)

I also aded a video apart form the screenshots because i dont have a microphone pluged in the pc, 
and so the emulator couldnt take the audio and convert it to text so i used my phone