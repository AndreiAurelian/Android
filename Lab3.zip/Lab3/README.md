chiar daca scrie lab1, este lab3
